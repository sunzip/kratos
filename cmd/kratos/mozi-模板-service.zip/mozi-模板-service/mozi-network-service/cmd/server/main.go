package main

import (
	"flag"
	"path"

	conf "git.hiscene.net/hiar_mozi/server/mozi-common/model/internal_conf"
	"git.hiscene.net/hifoundry/go-kit/constance/hiCommon"
	"git.hiscene.net/hifoundry/go-kit/discovery/hiNacos"
	"git.hiscene.net/hifoundry/go-kit/i18n/hiGoi18n"
	"git.hiscene.net/hifoundry/go-kit/log/hiZap"
	"git.hiscene.net/hifoundry/go-kit/tracing/hiOtel"
	"git.hiscene.net/hifoundry/go-kit/util/hiKratos"
	"go.uber.org/zap/zapcore"

	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/registry"
	"github.com/go-kratos/kratos/v2/transport/grpc"
	"github.com/go-kratos/kratos/v2/transport/http"

	_ "net/http/pprof"

	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log"

	"github.com/go-kratos/kratos/contrib/registry/nacos/v2"
	tracesdk "go.opentelemetry.io/otel/sdk/trace"
)

var flagConf string

func newApp(bc *conf.Bootstrap, logger log.Logger, hs *http.Server, gs *grpc.Server) *kratos.App {
	var registrar registry.Registrar
	if bc.Discovery.OnOff {
		namming, err := hiNacos.NewNamingClient(
			bc.Discovery.IPAddr,
			uint64(bc.Discovery.Port),
			hiNacos.WithNamespaceID(bc.Env),
		)
		if err != nil {
			panic(err)
		}
		registrar = nacos.New(namming)
	}

	return kratos.New(
		kratos.Name(bc.Name),
		kratos.Version(bc.Version),
		kratos.Metadata(map[string]string{}),
		kratos.Logger(logger),
		kratos.Server(hs, gs),
		kratos.Registrar(registrar),
	)
}

func main() {
	flag.StringVar(&flagConf, "conf", "../../config/config.dev.yaml", "config path, eg: -conf config.yaml")
	flag.Parse()

	var bc *conf.Bootstrap
	/*if err := hiViper.File2Struct(flagConf, &bc); err != nil {
		panic(err)
	}*/
	if err := hiKratos.InitConfig(flagConf, &bc); err != nil {
		panic(err)
	}

	loggerOpt := hiZap.Options{
		Level: zapcore.DebugLevel,
		Skip:  2,
	}
	// zap 开启stack trace logger, 用于service层输出
	stackLogger := hiZap.New(&loggerOpt)
	logger := log.With(hiZap.New(&loggerOpt), hiCommon.TraceID, tracing.TraceID())

	// 开启pprof，prometheus metrics
	go hiKratos.ListenMetricAndPprof(bc.Metrics.Addr)

	// openTelemetry
	_, err := hiOtel.NewTracerProvider(hiOtel.TracerProviderOption{
		Sampler:     tracesdk.TraceIDRatioBased(bc.Trace.Fraction),
		Endpoint:    bc.Trace.Endpoint,
		ServiceName: bc.Name,
	})
	if err != nil {
		panic(err)
	}

	langPath := path.Dir(flagConf) + "/i18n/"
	bundle := hiGoi18n.New(hiGoi18n.Options{
		Paths: []string{
			langPath + "example.en.toml",
			langPath + "example.zh.toml",
		},
	})

	app, cleanup, err := autoWireApp(bc, logger, stackLogger, bundle)
	if err != nil {
		panic(err)
	}
	defer cleanup()

	if err := app.Run(); err != nil {
		panic(err)
	}
}
