// +build wireinject

// The build tag makes sure the stub is not built in the final build.

package main

import (
	conf "git.hiscene.net/hiar_mozi/server/mozi-common/model/internal_conf"
	"git.hiscene.net/hiar_mozi/server/mozi-network-service/internal/data"
	"git.hiscene.net/hiar_mozi/server/mozi-network-service/internal/protocol"
	"git.hiscene.net/hifoundry/go-kit/log/hiZap"
	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/wire"
	"github.com/nicksnyder/go-i18n/v2/i18n"
)

func autoWireApp(*conf.Bootstrap, log.Logger, *hiZap.ZapLogger, *i18n.Bundle) (*kratos.App, func(), error) {
	panic(wire.Build(data.ProviderSet, protocol.ProviderSet,
		newApp))
}
