package protocol

import (
	"github.com/go-kratos/kratos/v2/transport/grpc"
	"github.com/go-kratos/kratos/v2/transport/http"
)

type PbServer struct {
}

func (s *PbServer) RegisterHTTP(srv *http.Server) {
}

func (s *PbServer) RegisterRPC(srv *grpc.Server) {
}
