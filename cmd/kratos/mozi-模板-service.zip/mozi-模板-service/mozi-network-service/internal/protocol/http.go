package protocol

import (
	"fmt"
	"time"

	netHttp "net/http"

	conf "git.hiscene.net/hiar_mozi/server/mozi-common/model/internal_conf"
	"git.hiscene.net/hiar_mozi/server/mozi-network-service/internal/data"
	selfMiddleware "git.hiscene.net/hiar_mozi/server/mozi-network-service/internal/pkg/middleware"
	"git.hiscene.net/hiar_mozi/server/mozi-network-service/internal/pkg/util"
	"git.hiscene.net/hifoundry/go-kit/i18n/hiGoi18n"
	"git.hiscene.net/hifoundry/go-kit/util/hiKratos"
	kjson "github.com/go-kratos/kratos/v2/encoding/json"
	"github.com/go-kratos/kratos/v2/errors"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/transport/http"
	"github.com/go-kratos/swagger-api/openapiv2"
	"github.com/nicksnyder/go-i18n/v2/i18n"
)

// NewHTTPServer new a HTTP server.
func NewHTTPServer(bc *conf.Bootstrap, logger log.Logger, server *PbServer, bundle *i18n.Bundle, data *data.Data) *http.Server {
	// 不需要验证token的地址
	checkTokenWhiteList := []string{
		"/api.mozi.device.v1.Device/SyncWvp",
	}
	c := bc.Server
	srv := http.NewServer(
		http.Address(c.HTTP.Addr),
		http.Timeout(time.Duration(c.HTTP.Timeout)*time.Second),
		http.Middleware(
			recovery.Recovery(),
			tracing.Server(),
			logging.Server(logger),
			hiGoi18n.Translator(bundle),
			validate(),
			hiKratos.HTTPReturnTraceID(),
			hiKratos.Server(selfMiddleware.CheckTokenMiddleWare(bc, data)).NotPath(checkTokenWhiteList...).Build(),
			// todo: license
			// hiKratos.Server(selfMiddleware.CheckLicenseMiddleWare(license)).NotPath(checkLicenseWhiteList...).Build(),
		),

		http.Logger(logger),
		// hiKratos.Encoder(),
		// hiKratos.ErrorEncoder(),

		Encoder(),
		ErrorEncoder(),
	)
	openAPIhandler := openapiv2.NewHandler()
	srv.HandlePrefix("/q/", openAPIhandler)
	server.RegisterHTTP(srv)

	return srv
}

type MyError struct {
	Code      int32             `json:"code,omitempty"`
	DetailMsg string            `json:"detailMsg,omitempty"`
	Message   string            `json:"message,omitempty"`
	Metadata  map[string]string `json:"metadata,omitempty"`
	RetCode   int32             `json:"retCode"`
}

func ErrorEncoder() http.ServerOption {
	return http.ErrorEncoder(func(w netHttp.ResponseWriter, r *netHttp.Request, err error) {
		// 拿到error并转换成kratos Error实体
		se := errors.FromError(err)

		// 通过Request Header的Accept中提取出对应的编码器
		codec, _ := http.CodecForRequest(r, "Accept")
		body, err := codec.Marshal(&MyError{
			DetailMsg: se.Reason,
			Message:   se.Message,
			Metadata:  se.Metadata,
			RetCode:   se.Code,
		})
		if err != nil {
			w.WriteHeader(netHttp.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		code := netHttp.StatusOK
		if se.Code == netHttp.StatusUnauthorized {
			code = netHttp.StatusUnauthorized
		}
		w.WriteHeader(code)
		w.Write(body)
		return
	})
}

const (
	defaultReason  = "SUCCESS"
	defaultMessage = "操作成功"
)

func Encoder() http.ServerOption {
	return http.ResponseEncoder(func(w netHttp.ResponseWriter, r *netHttp.Request, v interface{}) error {
		msg := hiKratos.GetMessage(w)
		if msg == "" {
			msg = defaultMessage
		}
		codec, _ := http.CodecForRequest(r, "Accept")
		// 枚举使用数字
		kjson.MarshalOptions.UseEnumNumbers = true
		data, err := codec.Marshal(v)

		// b, e := json.Marshal(v)
		// fmt.Println(b, e)
		// data = b

		if err != nil {
			return err
		}
		w.Header().Set("Content-Type", "application/json")

		serviceRet := util.GetHeader(w, util.ServiceRetHeader)
		if util.HileiaRecorder.Equal(serviceRet) {
			_, _ = w.Write([]byte(fmt.Sprintf(`{
				"code": %d,
				"message": "%s",
				}`, 0, "success")))
		} else {
			_, _ = w.Write([]byte(fmt.Sprintf(`{
			"retCode": %d,
			"detailMsg": "%s",
			"message": "%s",
			"data": %s
			}`, 0, defaultReason, msg, data)))
		}
		return nil
	})
}
