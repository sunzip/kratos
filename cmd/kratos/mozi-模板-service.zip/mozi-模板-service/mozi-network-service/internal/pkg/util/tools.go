package util

import (
	"crypto/hmac"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"sort"
	"strconv"
	"strings"
)

// Str2Uint8 字符串转uint32 FormatUint
func Str2Uint8(str string) uint8 {
	rtiStr := strings.TrimSpace(str)
	if len(rtiStr) <= 0 {
		return 0
	}
	id, err := strconv.ParseUint(rtiStr, 10, 64)
	if err != nil {
		//logger.Error("str: %v to uint32 error: %v", str, err)
		return 0
	}
	return uint8(id)
}

// Str2Uint64 字符串转uint64 FormatUint
func Str2Uint64(str string) uint64 {
	id, err := strconv.ParseUint(strings.TrimSpace(str), 10, 64)
	if err != nil {
		return 0
	}
	return id
}

// Str2int64 字符串转int64 FormaUint
func Str2int64(str string) int64 {
	id, err := strconv.ParseInt(strings.TrimSpace(str), 10, 64)
	if err != nil {
		//logger.Error("str: %v to int64 error: %v", str, err)
		return 0
	}
	return id
}

// Str2Uint32 字符串转uint32 FormatUint
func Str2Uint32(str string) uint32 {
	rtiStr := strings.TrimSpace(str)
	if len(rtiStr) <= 0 {
		return 0
	}
	id, err := strconv.ParseUint(rtiStr, 10, 64)
	if err != nil {
		//logger.Error("str: %v to uint32 error: %v", str, err)
		return 0
	}
	return uint32(id)
}

// Str2int32 Str2int32
func Str2int32(str string) int32 {
	id, err := strconv.ParseUint(str, 10, 64)
	if err != nil {
		//logger.Error("str: %v to int32 error: %v", str, err)
		return 0
	}
	return int32(id)
}

// Str2Ui32Arr 字符串转uint32 数组
func Str2Ui32Arr(str string) []uint32 {
	if len(str) <= 0 {
		return nil
	}
	sarr := strings.Split(str, ",")
	if sarr == nil || len(sarr) <= 0 {
		return nil
	}
	iarr := make([]uint32, 0)
	for _, key := range sarr {
		if strings.Trim(key, " ") != "" {
			iarr = append(iarr, Str2Uint32(key))
		}
	}
	return iarr
}

// StrFUint32 uint32 转 字符串
func StrFUint32(id uint32) string {
	return StrFUint64(uint64(id))
}

// StrFUint64 字符串转uint64 FormatUint
func StrFUint64(id uint64) string {
	return strconv.FormatUint(id, 10)
}

// StrFInt64 字符串转int64 FormatUint
func StrFInt64(id int64) string {
	return strconv.FormatInt(id, 10)
}

// StrFFloat64 StrFFloat64
func StrFFloat64(id float64) string {
	return strconv.FormatFloat(id, 'f', -1, 64)
}

// Str2Float64 Str2Float64
func Str2Float64(str string) float64 {
	rtiStr := strings.TrimSpace(str)
	if len(rtiStr) <= 0 {
		return 0
	}
	id, err := strconv.ParseFloat(rtiStr, 64)
	if err != nil {
		// logger.Error("str: %v to float64 error: %v", str, err)
		return 0
	}
	return id
}

// HMACSHA1 对字符串进行HMAC-SHA1加密
/*
 * 对字符串进行HMAC-SHA1加密
 * copy from common
 * @param	key			string
 * @param	plaintext 	string
 * @return				string
 */
func HMACSHA1(key, plaintext string) []byte {
	hashed := hmac.New(sha1.New, []byte(key))
	hashed.Write([]byte(plaintext))
	return hashed.Sum(nil)
}

// ActionGenSignature 计算签名
func ActionGenSignature(action, key, secret, timestamp, nonce string) string {
	params := []string{action, key, timestamp, nonce}
	sort.Strings(params)
	s := base64.StdEncoding.EncodeToString(HMACSHA1(secret, strings.Join(params, "")))
	return s
}

// ComputeHmac256 ComputeHmac256
func ComputeHmac256(message string, secret string) string {
	key := []byte(secret)
	h := hmac.New(sha256.New, key)
	h.Write([]byte(message))
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

// 创建key value的map; 成对出现
func NewMap(keyValues ...string) map[string]string {
	m := make(map[string]string)
	l := len(keyValues)
	for i := 0; i < l; i += 2 {
		if i+1 < l {
			m[keyValues[i]] = keyValues[i+1]
		}
	}
	return m
}
