package util

import (
	"context"
	"fmt"
	"net/http"

	"github.com/go-kratos/kratos/v2/transport"
)

const (
	ServiceRetHeader = "ServiceRet"
)

type ServiceRetEnum uint8

const (
	// 录制服务
	HileiaRecorder ServiceRetEnum = 1 << iota
)

func (t ServiceRetEnum) ToString() string {
	return fmt.Sprintf("%d", t)
}
func (t ServiceRetEnum) Equal(serviceRet string) bool {
	return fmt.Sprintf("%d", t) == serviceRet
}

// SetHeader 想要自定义返回message， 因框架问题，通过header船体
func SetHeader(ctx context.Context, headerKey string, value string) bool {
	tr, ok := transport.FromServerContext(ctx)
	if ok {
		tr.ReplyHeader().Set(headerKey, value)
	}
	return ok
}

// GetHeader 重写http.ResponseEncoder时，获取SetMessage设置的值
func GetHeader(w http.ResponseWriter, headerKey string) string {
	msg := w.Header().Get(headerKey)
	if msg != "" {
		w.Header().Del(headerKey)
	}
	return msg
}
