package util

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os/exec"
)

type NetWorkInfo struct {
	Name      string `json:"name"`
	Alias     string `json:"alias"`
	Ipv4      string `json:"ipv4"`
	Netmask   string `json:"netmask"`
	Gateway   string `json:"gateway"`
	Ipv6      string `json:"ipv6"`
	Prefixlen string `json:"prefixlen"`
}

func GetNetworkInfo() (*[]NetWorkInfo, error) {
	cmd := exec.Command("sh", "./networklist.sh")
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout // 标准输出
	cmd.Stderr = &stderr // 标准错误
	err := cmd.Run()
	outStr, errStr := stdout.String(), string(stderr.Bytes())
	fmt.Printf("out:\n%s\nerr:\n%s\n", outStr, errStr)
	if err != nil {
		log.Fatalf("cmd.Run() failed with %s\n", err)
	}
	rep := &[]NetWorkInfo{}
	err = json.Unmarshal(stdout.Bytes(), rep)
	if err != nil {
		log.Fatalf("cmd.Run() Unmarshal stdout failed with %s\n", err)
	}
	if len(*rep) > 0 {
		*rep = (*rep)[:len(*rep)-1]
	}
	fmt.Println("rep,", rep)
	return rep, nil
}
