package util

import "testing"

func Test_GetClientIp(t *testing.T) {
	GetClientIp()
}
