package util

import (
	"bytes"
	"crypto/tls"
	"io/ioutil"
	"net/http"
	"strings"
	"time"
)

var client *http.Client

func Dail(method string, url string, requestBodyJson []byte, header http.Header, timeout time.Duration) (*http.Response, error) {
	if client == nil {
		client = &http.Client{
			Transport: &http.Transport{
				TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
			},
			Timeout: timeout,
		}
	}
	req, _ := http.NewRequest(strings.ToUpper(method), url, bytes.NewReader(requestBodyJson))
	req.Header = header

	defer client.CloseIdleConnections()
	return client.Do(req)
}

/**
 * @Desc
 * @Param url 完整地址，GET请求参数通过path表示，http://xxx/login?username=xxx
 * @return
 **/
func HttpRequest(method string, url string, requestBodyJson []byte, header http.Header, timeout time.Duration) ([]byte, error) {
	response, err := Dail(method, url, requestBodyJson, header, timeout)
	if err != nil{
		return nil, err
	}

	defer response.Body.Close()

	var body []byte
	body, err = ioutil.ReadAll(response.Body)
	return body, err
}
