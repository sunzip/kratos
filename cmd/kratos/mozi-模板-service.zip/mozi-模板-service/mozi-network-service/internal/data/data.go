package data

import (
	"context"
	"time"

	conf "git.hiscene.net/hiar_mozi/server/mozi-common/model/internal_conf"
	"git.hiscene.net/hifoundry/go-kit/log/hiZap"
	"git.hiscene.net/hifoundry/go-kit/storage/hiMysql"
	"git.hiscene.net/hifoundry/go-kit/storage/hiRedis"
	"gorm.io/gorm"
)

var (
	ctx context.Context
	// 自动添加前缀
	autoRedisPrefix string
)

func init() {
	ctx = context.Background()
}

type (
	Prefix  struct{}
	MyRedis struct {
		Rdb    hiRedis.Client
		Prefix string
	}
)
type Data struct {
	dbInfo *conf.Database
	db     *gorm.DB
	rdb    hiRedis.Client
}

func NewData(bc *conf.Bootstrap, logger *hiZap.ZapLogger) (*Data, func(), error) {
	c := bc.Data
	var db *gorm.DB
	if c != nil && c.Mysql != nil {
		var err error
		db, err = hiMysql.New(&hiMysql.Options{
			Address:  c.Mysql.Address,
			UserName: c.Mysql.UserName,
			Password: c.Mysql.Password,
			DBName:   c.Mysql.DBName,
			// Tracer:   otel.GetTracerProvider(),
			Logger: logger,
		})
		if err != nil {
			return nil, nil, err
		}
		logger.Info("db connect:", c.Mysql.Address, ",driver:", c.Mysql.Driver)
	}

	var rClient hiRedis.Client
	if c != nil && c.Redis != nil {
		autoRedisPrefix = c.Redis.AutoPrefix
		var err error
		rClient, err = hiRedis.New(&hiRedis.Options{
			Addr:     c.Redis.Address,
			Password: c.Redis.Password,
			DB:       int(c.Redis.DB),
		})
		if err != nil {
			return nil, nil, err
		}
	}

	d := &Data{
		db:  db,
		rdb: rClient,
	}
	if c != nil {
		d.dbInfo = c.Mysql
	}
	return d, func() {
		d.rdb.Close()
	}, nil
}

// 单元测试使用, 设置mock db
func (d *Data) SetDb4Test(db *gorm.DB) {
	d.db = db
}

func (d *Data) DB(ctx context.Context) *gorm.DB {
	return d.db.WithContext(ctx)
}

func (d *Data) Redis(prefix string) *MyRedis {
	if len(prefix) == 0 {
		prefix = autoRedisPrefix
	}
	myredis := MyRedis{Prefix: prefix, Rdb: d.rdb}
	return &myredis
}

// key不需要加 prefix，自动加
func (t *MyRedis) RedisAdd(key, value string) error {
	err := t.Rdb.Set(ctx, t.Prefix+key, value, 0).Err()
	return err
}

// 手动添加过期时间的值
func (t *MyRedis) RedisAddAndExp(key, value string, exp time.Duration) error {
	err := t.Rdb.Set(ctx, t.Prefix+key, value, exp).Err()
	return err
}

// key不需要加 prefix，自动加
func (t *MyRedis) RedisGet(key string) (value string, err error) {
	return t.Rdb.Get(ctx, t.Prefix+key).Result()
}

// exist>0存在
func (t *MyRedis) RedisExist(key string) (exist int64, err error) {
	return t.Rdb.Exists(ctx, t.Prefix+key).Result()
}

// todo: 等go-kit 接口加了h操作, 再放开, 已说
//  key不需要加 prefix，自动加

// key不需要加 prefix，自动加
func (t *MyRedis) RedisHAdd(key, field, value string) error {
	err := t.Rdb.HSet(ctx, t.Prefix+key, field, value).Err()
	return err
}

// key不需要加 prefix，自动加
func (t *MyRedis) RedisHGet(key, field string) (value string, err error) {
	return t.Rdb.HGet(ctx, t.Prefix+key, field).Result()
}

//  key不需要加 prefix，自动加
func (t *MyRedis) RedisHExist(key, field string) (exist bool, err error) {
	return t.Rdb.HExists(ctx, t.Prefix+key, field).Result()
}

// key不需要加 prefix，自动加
func (t *MyRedis) RedisIncr(key string) (value int64, err error) {
	return t.Rdb.Incr(ctx, t.Prefix+key).Result()
}

// 删除key
//  key不需要加 prefix，自动加
func (t *MyRedis) RedisDel(key string) (value int64, err error) {
	return t.Rdb.Del(ctx, t.Prefix+key).Result()
}
